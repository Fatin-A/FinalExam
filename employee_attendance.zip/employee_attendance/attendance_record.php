<?php include 'db_connect.php' ?>
<div class="container-fluid">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header"><b>Attendance Record's</b></div>
			<div class="card-body">
				<form id="manage-attendance">
					<input type="hidden" name="id" value="">
					<div class="row justify-content-center">
						<label for="" class="mt-2">Department per Teams</label>
						<div class="col-sm-4">
				            <select name="class_team_id" id="class_team_id" class="custom-select select2 input-sm">
				                <option value=""></option>
				                <?php
				                $class = $conn->query("SELECT cs.*,concat(co.dept,' ',c.level) as `class`,s.team,f.name as fname FROM class_team cs inner join `class` c on c.id = cs.class_id inner join depts co on co.id = c.dept_id inner join leader f on f.id = cs.leader_id inner join teams s on s.id = cs.team_id ".($_SESSION['login_leader_id'] ? " where f.id = {$_SESSION['login_leader_id']} ":"")." order by concat(co.dept,' ',c.level) asc");
				                while($row=$class->fetch_assoc()):
				                ?>
				                <option value="<?php echo $row['id'] ?>" data-cid="<?php echo $row['id'] ?>" <?php echo isset($class_team_id) && $class_team_id == $row['id'] ? 'selected' : '' ?>><?php echo $row['class'].' '.$row['team']. ' [ '.$row['fname'].' ]' ?></option>
				                <?php endwhile; ?>
				            </select>
						</div>
						<div class="col-sm-3">
							<input type="date" name="doc" id="doc" value="<?php echo date('Y-m-d') ?>" class="form-control">
						</div>
						<div class="col-sm-2">
							<button class="btn  btn-primary" type="button" id="filter">Filter</button>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-md-12" id='att-list'>
							<center><b><h4><i>Please Select Class First.</i></h4></b></center>
						</div>
						<div class="col-md-12"  style="display: none" id="submit-btn-field">
							<center>
								<button class="btn btn-primary btn-sm col-sm-3" type="button" id="edit_att"><i class="fa fa-edit" data-id=''></i> Edit</button>
								<button class="btn btn-success btn-sm col-sm-3" type="button" id="print_att"><i class="fa fa-print"></i> Print</button>
							</center>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<div id="table_clone" style="display: none">
	<table width="100%">
		<tr>
			<td width="50%">
				<p>Department: <b class="dept"></b></p>
				<p>Team: <b class="team"></b></p>
			</td>
			<td width="50%">
				<p>Level: <b class="class"></b></p>
				<p>Date of Class: <b class="doc"></b></p>
			</td>
		</tr>
	</table>
	<table class='table table-bordered table-hover att-list'>
		<thead>
			<tr>
				<th class="text-center" width="5%">#</th>
				<th width="20%">Employee</th>
				<th>Attendance</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>
<div id="chk_clone" style="display: none">
	<div class="d-flex justify-content-center chk-opts">
		<div class="form-check form-check-inline">
		  <input class="form-check-input late-inp" type="checkbox" value="0" class="customvalue" readonly="">
		  <label class="form-check-label late-lbl">Late</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input absent1-inp" type="checkbox" value="1" readonly="">
		  <label class="form-check-label absent1-lbl">Absent AM</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input absent2-inp" type="checkbox" value="2" readonly="">
		  <label class="form-check-label absent2-lbl">Absent PM</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input mc-inp" type="checkbox" value="3" readonly="">
		  <label class="form-check-label mc-lbl">MC</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input al-inp" type="checkbox" value="4" readonly="">
		  <label class="form-check-label al-lbl">Annual leave</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input el-inp" type="checkbox" value="5" readonly="">
		  <label class="form-check-label el-lbl">Emergency leave</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input ul-inp" type="checkbox" value="6" readonly="">
		  <label class="form-check-label ul-lbl">Unpaid leave</label>
		</div>
		<div class="form-check form-check-inline">
		  <input class="form-check-input present-inp" type="checkbox" value="7" readonly="">
		  <label class="form-check-label present-lbl"></label>
		</div>
	</div>
</div>
<style>
	.present-inp,.late-inp,.absent1-inp,.absent2-inp,.mc-inp,.al-inp,.el-inp,.ul-inp,.present-lbl,.late-lbl,.absent1-lbl,.absent2-lbl,.mc-lbl,.al-lbl,.el-lbl,.ul-lbl{
		cursor: pointer;
	}
</style>
<noscript>
	<style>
		table.att-list{
			width:100%;
			border-collapse:collapse
		}
		table.att-list td,table.att-list th{
			border:1px solid
		}
		.text-center{
			text-align:center
		}
	</style>
</noscript>
<script>

	$('#filter').click(function(){
		start_load()
		$.ajax({
			url:'ajax.php?action=get_att_record',
			method:'POST',
			data:{class_team_id:$('#class_team_id').val(),doc:$('#doc').val()},
			success:function(resp){
				if(resp){
					resp = JSON.parse(resp)
					var _table = $('#table_clone').clone()
					$('#att-list').html('')
					$('#att-list').append(_table)
					var _type = ['Late','Absent (AM)','Absent (PM)','MC','AL','EL','UL','Present'];
					var data = !!resp.data ? resp.data : [];
					var record = !!resp.record ? resp.record : [];
					var attendance_id = !!resp.attendance_id ? resp.attendance_id : '';
					if(Object.keys(data).length > 0){
						var i = 1;
						Object.keys(data).map(function(k){
							var name = data[k].name;
							var id = data[k].id;
							var tr = $('<tr></tr>')

							// opts.find('.present-inp').attr({'name':'type['+id+']','id':'present_'+id})
							// opts.find('.absent-inp').attr({'name':'type['+id+']','id':'absent_'+id})
							// opts.find('.late-inp').attr({'name':'type['+id+']','id':'late_'+id})

							// opts.find('.present-lbl').attr({'for':'present_'+id})
							// opts.find('.absent-lbl').attr({'for':'absent_'+id})
							// opts.find('.late-lbl').attr({'for':'late_'+id})

							tr.append('<td class="text-center">'+(i++)+'</td>')
							tr.append('<td class="">'+(name)+'</td>')
							var td = '<td>';
								td += '<input type="hidden" name="employee_id['+id+']" value="'+id+'">';
								td += !!record[k].type ? _type[record[k].type] : '';
								td += '</td>';
							tr.append(td)

							_table.find('table.att-list tbody').append(tr)
						})
						$('#submit-btn-field').show()
						$('#edit_att').attr('data-id',attendance_id)
					}else{
							var tr = $('<tr></tr>')
							tr.append('<td class="text-center" colspan="3">No data.</td>')
							_table.find('table.att-list tbody').append(tr)
						$('#submit-btn-field').attr('data-id','').hide()
						$('#edit_att').attr('data-id','')
					} 
					$('#att-list').html('')
					_table.find('.dept').text(!!resp.details.dept ? resp.details.dept : '')
					_table.find('.team').text(!!resp.details.team ? resp.details.team : '')
					_table.find('.class').text(!!resp.details.class ? resp.details.class : '')
					_table.find('.doc').text(!!resp.details.doc ? resp.details.doc : '')
					$('#att-list').append(_table.html())
					if(Object.keys(record).length > 0){
						Object.keys(record).map(k=>{
							// console.log('[name="type['+record[k].employee_id+']"][value="'+record[k].type+'"]')
							$('#att-list').find('[name="type['+record[k].employee_id+']"][value="'+record[k].type+'"]').prop('checked',true)
						})
					}
				}
			},
			complete:function(){
				$("input[readonly]").on('keyup keypress change',function(e){
					e.preventDefault()
					return false;
				});
				$('#edit_att').click(function(){
					location.href = 'index.php?page=check_attendance&attendance_id='+$(this).attr('data-id')
				})
				end_load()
			}
		})
	})
	$('#manage-attendance').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_attendance',
			method:'POST',
			data:$(this).serialize(),
			success:function(resp){
				if(resp==1){
					  alert_toast("Data successfully saved.",'success')
                        setTimeout(function(){
                            location.reload()
                        },1000)
				}else if(resp ==2){
					  alert_toast("Class already has an attendance record with the selected team and date.",'danger')
					  end_load();
				}
			}
		})
	})
	$('#print_att').click(function(){
		var _c = $('#att-list').html();
		var ns = $('noscript').clone();
		var nw = window.open('','_blank','width=900,height=600')
		nw.document.write(_c)
		nw.document.write(ns.html())
		nw.document.close()
		nw.print()
		setTimeout(() => {
			nw.close()
		}, 500);
	})
</script>